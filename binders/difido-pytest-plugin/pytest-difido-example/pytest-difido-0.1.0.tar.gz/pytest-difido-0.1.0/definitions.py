import os
root_dir = os.path.dirname(os.path.abspath(__file__))  # This is your Project Root
